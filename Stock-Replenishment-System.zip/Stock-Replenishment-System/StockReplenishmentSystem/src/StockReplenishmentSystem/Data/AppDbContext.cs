using Microsoft.EntityFrameworkCore;
using StockReplenishmentSystem.Models;

namespace StockReplenishmentSystem.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<ReplenishmentRequest> Requests => Set<ReplenishmentRequest>();
    public DbSet<ReplenishmentItem> Items => Set<ReplenishmentItem>();
}
