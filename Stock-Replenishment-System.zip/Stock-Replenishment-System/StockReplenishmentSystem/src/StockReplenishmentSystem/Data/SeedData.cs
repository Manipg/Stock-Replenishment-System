using StockReplenishmentSystem.Models;

namespace StockReplenishmentSystem.Data;

public static class SeedData
{
    public static async Task InitializeAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<AppDbContext>();

        db.Requests.AddRange(
            new ReplenishmentRequest {
                RequesterName = "Record1", 
                Location = "Production Line A",
                Priority = RequestPriority.Urgent, 
                Status = RequestStatus.Draft,
                Items = [new() { ArticleNumber = "ART001", Description = "Steel Sheet", RequestedQuantity = 100 }]
            },
            new ReplenishmentRequest {
                RequesterName = "Record2", 
                Location = "Production Line B",
                Priority = RequestPriority.Normal,
                Status = RequestStatus.Submitted,
                ValidationStatus = ValidationStatus.Available,
                ValidationMessage = "Stock check completed. Items are available.",
                Items = [new() { ArticleNumber = "ART002", Description = "Copper Wire", RequestedQuantity = 50 }]
            },
            new ReplenishmentRequest {
                RequesterName = "Record3", 
                Location = "Warehouse 1",
                Priority = RequestPriority.Low, 
                Status = RequestStatus.Approved,
                ValidationStatus = ValidationStatus.Available,
                Items = [new() { ArticleNumber = "ART003", Description = "Fasteners", RequestedQuantity = 200 }]
            });
        await db.SaveChangesAsync();
    }
}
