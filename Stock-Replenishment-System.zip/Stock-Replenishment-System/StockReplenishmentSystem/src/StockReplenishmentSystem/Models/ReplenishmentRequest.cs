using System.ComponentModel.DataAnnotations;

namespace StockReplenishmentSystem.Models;

public class ReplenishmentRequest
{
    public int Id { get; set; }

    [Required]
    [MaxLength(100)] 
    public string RequesterName { get; set; } = "";

    [Required]
    [MaxLength(100)] 
    public string Location { get; set; } = "";

    public RequestPriority Priority { get; set; } = RequestPriority.Normal;
    public RequestStatus Status { get; set; } = RequestStatus.Draft;
    public ValidationStatus ValidationStatus { get; set; } = ValidationStatus.NotStarted;

    public string? ValidationMessage { get; set; }
    public string? RejectionReason { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? SubmittedAtUtc { get; set; }
    public DateTime? FulfilledAtUtc { get; set; }
    public List<ReplenishmentItem> Items { get; set; } = [];
}

public class ReplenishmentItem
{
    public int Id { get; set; }
    public int ReplenishmentRequestId { get; set; }

    [Required]
    [MaxLength(40)] 
    public string ArticleNumber { get; set; } = "";

    [Required]
    [MaxLength(200)] 
    public string Description { get; set; } = "";

    [Range(1, 1000000)] 
    public int RequestedQuantity { get; set; }

    [Range(0, 1000000)] 
    public int? FulfilledQuantity { get; set; }
}