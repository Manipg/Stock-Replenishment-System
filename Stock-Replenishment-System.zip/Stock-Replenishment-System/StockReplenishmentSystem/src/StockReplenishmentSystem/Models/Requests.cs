using System.ComponentModel.DataAnnotations;

namespace StockReplenishmentSystem.Models;

public record CreateRequestDto(
    [Required]
    string RequesterName,
    [Required]
    string Location,
    RequestPriority Priority,
    [Required]
    [MinLength(1)]
    List<CreateItemDto> Items);

public record CreateItemDto(
    [Required]
    string ArticleNumber,
    [Required]
    string Description,
    [Range(1, int.MaxValue)]
    int RequestedQuantity);

public record RejectRequestDto(
    [Required] 
    string Reason);
public record FulfillRequestDto(
    [Required]
    [MinLength(1)] 
    List<FulfilledItemDto> Items);
public record FulfilledItemDto(int ItemId, int Quantity);
public record PagedResult<T>(IReadOnlyList<T> Items);
