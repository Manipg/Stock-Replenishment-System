using Microsoft.AspNetCore.Mvc;
using StockReplenishmentSystem.Models;
using StockReplenishmentSystem.Services;

[ApiController]
[Route("api/requests")]
public class ReplenishmentRequestsController : ControllerBase
{
    private readonly IReplenishmentService _service;
    public ReplenishmentRequestsController(IReplenishmentService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<ActionResult<ReplenishmentRequest>> Get(RequestStatus? status, RequestPriority? priority, string? location)
    {
        return Ok(await _service.GetAsync(status, priority, location));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ReplenishmentRequest>> GetById(int id)
    {
        var request = await _service.GetByIdAsync(id);

        if (request == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(request);
        }
    }

    [HttpPost]
    public async Task<ActionResult<ReplenishmentRequest>> Create(CreateRequestDto dto)
    {
        if (!ModelState.IsValid) 
        {
            return ValidationProblem(ModelState);
        }
        try
        {
            var created = await _service.CreateAsync(dto);

            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPost("{id:int}/submit")]
    public async Task<IActionResult> Submit(int id)
    {
        bool result = await _service.SubmitAsync(id);

        if (result)
        {
            return Accepted(new
            {
                message = "Submitted. Stock validation is running in background."
            });
        }
        else
        {
            return Conflict(new
            {
                message = "Request not found, not in Draft status."
            });
        }
    }

    [HttpPost("{id:int}/approve")]
    public async Task<IActionResult> Approve(int id)
    {
        bool result = await _service.ReviewAsync(id, true, null);

        if (result)
        {
            return NoContent();
        }
        else
        {
            return Conflict(new
            {
                message = "Request must be submitted and stock validation must be available."
            });
        }
    }

    [HttpPost("{id:int}/reject")]
    public async Task<IActionResult> Reject(int id, RejectRequestDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Reason))
        {
            return BadRequest(new
            {
                message = "Rejection reason is required."
            });
        }

        bool result = await _service.ReviewAsync(id, false, dto.Reason);

        if (result)
        {
            return NoContent();
        }
        else
        {
            return Conflict(new
            {
                message = "Only submitted requests can be rejected."
            });
        }
    }

    [HttpPost("{id:int}/fulfill")]
    public async Task<IActionResult> Fulfill(int id, FulfillRequestDto dto)
    {
        var result = await _service.FulfillAsync(id, dto);

        if (result.Success)
        {
            return NoContent();
        }
        else
        {
            return BadRequest(new
            {
                message = result.Error
            });
        }
    }
}
