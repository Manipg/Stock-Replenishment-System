using StockReplenishmentSystem.Models;

namespace StockReplenishmentSystem.Services;

public interface IReplenishmentService
{
    Task<PagedResult<ReplenishmentRequest>> GetAsync(RequestStatus? status, RequestPriority? priority, string? location);
    Task<ReplenishmentRequest?> GetByIdAsync(int id);
    Task<ReplenishmentRequest> CreateAsync(CreateRequestDto dto);
    Task<bool> SubmitAsync(int id);
    Task<bool> ReviewAsync(int id, bool approve, string? reason);
    Task<(bool Success, string? Error)> FulfillAsync(int id, FulfillRequestDto dto);
}
