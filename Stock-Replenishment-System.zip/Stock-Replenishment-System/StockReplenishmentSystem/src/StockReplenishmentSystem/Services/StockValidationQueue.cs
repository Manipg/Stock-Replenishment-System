using System.Threading.Channels;

namespace StockReplenishmentSystem.Services;

public interface IStockValidationQueue
{
    ValueTask QueueAsync(int requestId, CancellationToken cancellationToken = default);
    ValueTask<int> DequeueAsync(CancellationToken cancellationToken);
}

public class StockValidationQueue : IStockValidationQueue
{
    private readonly Channel<int> _channel = Channel.CreateUnbounded<int>();
    public ValueTask QueueAsync(int requestId, CancellationToken cancellationToken = default)
    {
        return _channel.Writer.WriteAsync(requestId, cancellationToken);
    }
    public ValueTask<int> DequeueAsync(CancellationToken cancellationToken)
    {
        return _channel.Reader.ReadAsync(cancellationToken);
    }
}
