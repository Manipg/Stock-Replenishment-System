using Microsoft.EntityFrameworkCore;
using StockReplenishmentSystem.Data;
using StockReplenishmentSystem.Models;

namespace StockReplenishmentSystem.Services;

public class ReplenishmentService(AppDbContext db, IStockValidationQueue queue) : IReplenishmentService
{
    public async Task<PagedResult<ReplenishmentRequest>> GetAsync(RequestStatus? status, RequestPriority? priority, string? location)
    {
        var query = db.Requests.Include(x => x.Items).AsNoTracking().AsQueryable();
        if (status.HasValue) query = query.Where(x => x.Status == status);
        if (priority.HasValue) query = query.Where(x => x.Priority == priority);
        if (!string.IsNullOrWhiteSpace(location))
            query = query.Where(x => x.Location.Contains(location));
        var items = await query.OrderByDescending(x => x.CreatedAtUtc).ToListAsync();
        return new(items);
    }

    public Task<ReplenishmentRequest?> GetByIdAsync(int id) 
    { 
        return db.Requests.Include(x => x.Items).AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<ReplenishmentRequest> CreateAsync(CreateRequestDto dto)
    {
        if (dto.Items is null || dto.Items.Count == 0)
        {
            throw new ArgumentException("At least one material item is required.");
        } 

        var request = new ReplenishmentRequest 
        {
            RequesterName = dto.RequesterName.Trim(),
            Location = dto.Location.Trim(),
            Priority = dto.Priority,
            Status = RequestStatus.Draft,
            Items = dto.Items.Select(x => new ReplenishmentItem 
            {
                ArticleNumber = x.ArticleNumber.Trim(),
                Description = x.Description.Trim(),
                RequestedQuantity = x.RequestedQuantity
            }).ToList()
        };
        db.Requests.Add(request);
        await db.SaveChangesAsync();
        return request;
    }

    public async Task<bool> SubmitAsync(int id)
    {
        var request = await db.Requests.Include(x => x.Items).FirstOrDefaultAsync(x => x.Id == id);
        if (request is null || request.Status != RequestStatus.Draft || request.Items.Count == 0) return false;
        request.Status = RequestStatus.Submitted;
        request.SubmittedAtUtc = DateTime.UtcNow;
        request.ValidationStatus = ValidationStatus.Pending;
        request.ValidationMessage = "Stock availability check is in progress.";
        await db.SaveChangesAsync();
        await queue.QueueAsync(id);
        return true;
    }

    public async Task<bool> ReviewAsync(int id, bool approve, string? reason)
    {
        var request = await db.Requests.FirstOrDefaultAsync(x => x.Id == id);
        if (request is null || request.Status != RequestStatus.Submitted) return false;
        if (approve && request.ValidationStatus != ValidationStatus.Available) return false;
        if (!approve && string.IsNullOrWhiteSpace(reason)) return false;
        request.Status = approve ? RequestStatus.Approved : RequestStatus.Rejected;
        request.RejectionReason = approve ? null : reason!.Trim();
        await db.SaveChangesAsync();
        return true;
    }

    public async Task<(bool Success, string? Error)> FulfillAsync(int id, FulfillRequestDto dto)
    {
        var request = await db.Requests.Include(x => x.Items).FirstOrDefaultAsync(x => x.Id == id);
        if (request is null) return (false, "Request not found.");
        if (request.Status != RequestStatus.Approved) return (false, "Only approved requests can be fulfilled.");
        foreach (var supplied in dto.Items)
        {
            var item = request.Items.FirstOrDefault(x => x.Id == supplied.ItemId);
            if (item is null) return (false, $"Item {supplied.ItemId} does not belong to this request.");
            if (supplied.Quantity < 0 || supplied.Quantity > item.RequestedQuantity)
                return (false, $"Fulfilled quantity for {item.ArticleNumber} must be between 0 and {item.RequestedQuantity}.");
            item.FulfilledQuantity = supplied.Quantity;
        }
        if (request.Items.Any(x => x.FulfilledQuantity is null))
        {
            return (false, "Provide a fulfilled quantity for every item.");
        }
        request.Status = RequestStatus.Fulfilled;
        request.FulfilledAtUtc = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return (true, null);
    }
}