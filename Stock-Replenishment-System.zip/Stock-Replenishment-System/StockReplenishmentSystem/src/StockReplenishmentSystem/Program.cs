using Microsoft.AspNetCore.Components;
using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;
using StockReplenishmentSystem.Components;
using StockReplenishmentSystem.Data;
using StockReplenishmentSystem.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

// Blazor
builder.Services.AddRazorComponents().AddInteractiveServerComponents();

// HttpClient for Blazor
builder.Services.AddScoped(sp =>
    new HttpClient
    {
        BaseAddress = new Uri(sp.GetRequiredService<NavigationManager>().BaseUri)
    });

// MudBlazor
builder.Services.AddMudServices();

// InMemory Database
builder.Services.AddDbContext<AppDbContext>(options => options.UseInMemoryDatabase("StockReplenishmentDb"));

// Business Services
builder.Services.AddScoped<IReplenishmentService, ReplenishmentService>();

// Background Queue
builder.Services.AddSingleton<IStockValidationQueue, StockValidationQueue>();

var app = builder.Build();

// Seed data
using (var scope = app.Services.CreateScope())
{
    await SeedData.InitializeAsync(scope.ServiceProvider);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();
app.MapControllers();

app.MapRazorComponents<App>().AddInteractiveServerRenderMode();
app.Run();

public partial class Program { }