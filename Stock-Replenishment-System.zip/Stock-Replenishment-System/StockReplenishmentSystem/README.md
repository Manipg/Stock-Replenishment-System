# Stock Replenishment Request System

## Requirements
- .NET 10 SDK
- No SQL Server required; EF Core InMemory is used.

## Run
```bash
dotnet restore
dotnet build
dotnet run --project src/StockReplenishmentSystem
```
Open http://localhost:5080.

## Test
```bash
dotnet test
```

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | /api/requests?page=1&pageSize=10 | List with pagination and optional status, priority, location filters |
| GET | /api/requests/{id} | Request details |
| POST | /api/requests | Create Draft |
| POST | /api/requests/{id}/submit | Submit and queue stock validation |
| POST | /api/requests/{id}/approve | Approve after stock check passes |
| POST | /api/requests/{id}/reject | Reject with mandatory reason |
| POST | /api/requests/{id}/fulfill | Record fulfilled quantity for every line |

## Important design notes
- The stock check is queued using `Channel<T>` and processed by a `BackgroundService`. The submit endpoint returns HTTP 202 Accepted quickly.
- The UI can refresh GET /api/requests/{id} or the list to see ValidationStatus change from Pending to Available/Insufficient.
- The fake stock service waits 3–6 seconds and treats a requested quantity above 500 as unavailable. Replace this class with an HTTP client integration to a real inventory service.
- InMemory database is volatile: data resets when the app restarts. Use SQLite or SQL Server for persistence in production.
- This sample focuses on the assignment workflow. Add authentication/authorization, audit history, retry/dead-letter handling and robust partial-fulfilment rules before production use.
