using Microsoft.EntityFrameworkCore;
using NSubstitute;
using NUnit.Framework;
using StockReplenishmentSystem.Data;
using StockReplenishmentSystem.Models;
using StockReplenishmentSystem.Services;

namespace StockReplenishmentSystem.Tests;

[TestFixture]
public class ReplenishmentServiceTests
{
    private AppDbContext _db = null!;
    private IStockValidationQueue _queue = null!;
    private ReplenishmentService _service = null!;

    [SetUp]
    public void Setup()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
        _db = new AppDbContext(options);
        _queue = Substitute.For<IStockValidationQueue>();
        _service = new ReplenishmentService(_db, _queue);
    }

    [TearDown] public void TearDown() => _db.Dispose();

    [Test]
    public async Task CreateAsync_CreatesDraftWithItems()
    {
        var dto = new CreateRequestDto("Test Worker", "Line A", RequestPriority.Urgent,
            [new CreateItemDto("A100", "Steel", 20)]);
        var result = await _service.CreateAsync(dto);
        Assert.That(result.Status, Is.EqualTo(RequestStatus.Draft));
        Assert.That(result.Items, Has.Count.EqualTo(1));
    }

    [Test]
    public async Task SubmitAsync_ChangesStatusAndQueuesValidation()
    {
        var request = new ReplenishmentRequest {
            RequesterName = "Worker", Location = "Line A",
            Items = [new ReplenishmentItem { ArticleNumber = "A1", Description = "Bolt", RequestedQuantity = 5 }]
        };
        _db.Requests.Add(request);
        await _db.SaveChangesAsync();

        var submitted = await _service.SubmitAsync(request.Id);

        Assert.That(submitted, Is.True);
        Assert.That(request.Status, Is.EqualTo(RequestStatus.Submitted));
        Assert.That(request.ValidationStatus, Is.EqualTo(ValidationStatus.Pending));
        await _queue.Received(1).QueueAsync(request.Id, Arg.Any<CancellationToken>());
    }
}
